package database

import (
	"fmt"
	"log"
	"strconv"
	"time"

	"github.com/goNfCollector/common"
	"github.com/goNfCollector/configurations"
	"github.com/goNfCollector/database/model"
	"github.com/gookit/color"
	"github.com/sirupsen/logrus"
)

// write metrics to db
func (p *Postgres) write(metrics []common.Metric) {

	if p.closed {
		return
	}

	successWrites := 0
	p.pendingWites += 1
	p.currentId += 1

	defer func() { p.pendingWites -= 1 }()

	// color.Green.Printf("[%v] I am in thr write....!\n", p.currentId)

	// define device ID default value
	// var deviceID uint = 0
	// var err error

	// check if metrics length > 0
	if len(metrics) == 0 {
		// no metrics
		p.Debuuger.Verbose(fmt.Sprintf("[%d]-%s: (metrics length: %v)",
			configurations.ERROR_NO_METRICS_IN_THE_ARRAY.Int(),
			configurations.ERROR_NO_METRICS_IN_THE_ARRAY, len(metrics)),
			logrus.ErrorLevel,
		)
		return
	}

	// arrFlows defines for bach insert
	// on database to decrease the chance of
	// max_connection error
	var arrFlows []model.Flow

	// loop through metrics and write
	for _, m := range metrics {
		color.BgGray.Printf("%v %v", m.SrcIP, m.DstIP)

		t := time.Now().Add(-time.Duration(m.Time.Second()))

		by, _ := strconv.Atoi(m.Bytes)
		pa, _ := strconv.Atoi(m.Packets)

		humanReadableFlags, fin, syn, rst, psh, ack, urg, ece, cwr := p._tcpFlags(m.TCPFlags)

		flow := model.Flow{
			Device:  m.Device,
			Version: m.FlowVersion,

			Protocol:     m.Protocol,
			ProtocolName: m.ProtoName,

			InEthernetIndex:  m.InEthernet,
			OutEthernetIndex: m.OutEthernet,

			// SrcASN:       p.asnLookup(m.SrcIP),
			SrcHost:      m.SrcIP,
			SrcPortName:  m.SrcPort,
			SrcPortProto: m.SrcPortName,

			SrcCountryShort: m.SrcIp2lCountryShort,
			SrcCountryLong:  m.SrcIp2lCountryLong,
			SrcRegion:       m.SrcIp2lState,
			SrcLatitude:     m.SrcIp2lLat,
			SrcLongitude:    m.SrcIp2lLong,

			SrcIsThreat:     false,
			SrcThreatSource: "",

			// DstASN:       p.asnLookup(m.DstIP),
			DstHost:      m.DstIP,
			DstPortName:  m.DstPort,
			DstPortProto: m.DstPortName,

			DstCountryShort: m.DstIp2lCountryShort,
			DstCountryLong:  m.DstIp2lCountryLong,
			DstRegion:       m.DstIp2lState,
			DstLatitude:     m.DstIp2lLat,
			DstLongitude:    m.DstIp2lLong,

			DstIsThreat:     false,
			DstThreatSource: "",

			NextHop:             m.NextHop,
			NextHopCountryShort: "",
			NextHopCountryLong:  "",
			NextHopRegion:       "",
			NextHopLatitude:     "",
			NextHopLongitude:    "",

			NextHopIsThreat:     false,
			NextHopThreatSource: "",

			Flags:   humanReadableFlags,
			FlagFin: fin,
			FlagSyn: syn,
			FlagRst: rst,
			FlagPsh: psh,
			FlagAck: ack,
			FlagUrg: urg,
			FlagEce: ece,
			FlagCwr: cwr,

			Byte:   uint(by),
			Packet: uint(pa),
		}

		// set flow real date/time
		flow.CreatedAt = t
		flow.UpdatedAt = t

		// append flow to arrays
		arrFlows = append(arrFlows, flow)

	}

	log.Println()

	result := p.db.CreateInBatches(arrFlows, len(arrFlows))

	color.Green.Printf("Wrote: %v -> %v\n", result.RowsAffected, len(metrics))

	if result.Error != nil {
		p.Debuuger.Verbose(fmt.Sprintf("[%d]-%s: ([FLOW] %v)",
			configurations.ERROR_CAN_T_INSERT_METRICS_TO_POSTGRES_DB.Int(),
			configurations.ERROR_CAN_T_INSERT_METRICS_TO_POSTGRES_DB, result.Error),
			logrus.ErrorLevel,
		)
		if len(metrics)-int(result.RowsAffected) > 0 {
			p.Debuuger.Verbose(fmt.Sprintf("'%v' has not been insterted due to error.", len(metrics)-successWrites), logrus.WarnLevel)
		}
	}

	if result.RowsAffected > 0 {
		p.Debuuger.Verbose(fmt.Sprintf("'%v' out of '%v' has been inserted to db.", int(result.RowsAffected), len(metrics)), logrus.DebugLevel)
	}

}
